import courses from "./courses.json";
import modules from "./modules.json";
import assignment from "./assignment.json"
import enrollments from "./enrollments.json"
import users from "./users.json"
export {  courses, modules, assignment, enrollments, users  };
